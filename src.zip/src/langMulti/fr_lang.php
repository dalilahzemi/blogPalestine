<?php
$lang = array(
    'langMulti' => 'fr',
    'title' => 'Titre de la page',
    'blog_title' => 'blog de Palastin',
    'home' => 'Accueil',
    'profile' => 'Profil',
    'published_by' => 'Publié par ',
    'no_results' => 'Aucun résultat trouvé',
    'rights_reserved' => 'Tous droits réservés',
    'add_article'=> 'ajouter',
    'content'=> 'contenue de l article ',
    'lang_fr' => 'Français',
    'lang_en' => 'Anglais'
);
?>


