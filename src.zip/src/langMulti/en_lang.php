<?php
$lang = array(
    'langMulti' => 'en',
    'title' => 'Page Title',
    'blog_title' => 'palastin s blogs',
    'home' => 'Home',
    'profile' => 'Profile',
    'published_by' => 'Published by ',
    'no_results' => 'No results found',
    'rights_reserved' => 'All rights reserved',
    'add_article'=> 'add article',
    'lang_fr' => 'French',
    'lang_en' => 'English'
);
?>


