<?php
include 'db.php';

function getArticles($id) {
    global $conn;
    $sql = "SELECT * FROM article WHERE id_user=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result;
}

function addArticle($titre, $contenu, $chemin_image, $id_user) {
    global $conn;
    $sql = "INSERT INTO article (titre, contenu, chemin_image, id_user) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssi", $titre, $contenu, $chemin_image, $id_user);
    return $stmt->execute();
}

function deleteArticle($id_article) {
    global $conn;
    $sql = "DELETE FROM article WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id_article);
    return $stmt->execute();
}

function updateArticle($id_article, $titre, $contenu, $chemin_image) {
    global $conn;
    $sql = "UPDATE article SET titre=?, contenu=?, chemin_image=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssi", $titre, $contenu, $chemin_image, $id_article);
    return $stmt->execute();
}

function getUserInfo($id) {
    global $conn;
    $sql = "SELECT nom, prenom FROM utilisateurs WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        return $user['prenom'] . ' ' . $user['nom'];
    } else {
        return "Utilisateur introuvable";
    }
}
?>
